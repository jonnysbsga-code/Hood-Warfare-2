# HW2 native in-game cheat menu

## Mouse controls and themes

F6 opens the clickable native menu and releases the cursor. Click a category or row;
right-click a row to choose its previous value. PREV/NEXT scrolls longer option lists.
Click X or press F6 to close. The mod temporarily disables pawn input while the menu
is open, then restores it when closed. Keyboard navigation remains available.

Header swatches select cyan, purple, red, green or gold. The Settings page also offers
a CUSTOM theme with separate red, green and blue accent controls (0–255 in steps of 16).
Themes apply to tabs, highlights, selection indicators and option values.

Mouse input, DPI conversion, color changes and gameplay-input restoration pass the
regression simulation. Their behavior and appearance still need a running-game check.

## Installing the GitHub package

1. Install a compatible experimental [UE4SS release](https://github.com/UE4SS-RE/RE-UE4SS/releases/tag/experimental-latest).
   The development loader was v3.0.1-1181-g83330635; it is not bundled in this package.
2. In the extracted SteamRIP layout, open `Hood Warfare 2/HW2/Binaries/Win64/`.
   This contains `HW2-HoodWarfare2-Win64-Shipping.exe`.
3. Put UE4SS's `dwmapi.dll` and `ue4ss` folder beside that shipping executable.
4. Copy this repository's `HW2CheatMenu` folder into `Win64/ue4ss/Mods/`.
5. Add `HW2CheatMenu : 1` to `ue4ss/Mods/mods.txt`, preserving existing entries.
6. Launch `HW2.exe` normally and press F6.

The package has five required Lua files in `HW2CheatMenu/Scripts`: `main.lua`,
`MenuView.lua`, `MouseMenu.lua`, `BoxESP.lua` and `TargetLife.lua`, plus `enabled.txt`.
Restart after updates. Ctrl+R hot reload additionally requires
`EnableHotReloadSystem = 1` in `ue4ss/UE4SS-settings.ini` before game startup.

Launch `Hood Warfare 2/HW2.exe` normally. The UE4SS mod loads the menu inside the game.
The former PowerShell companion window is no longer used.

## Controls

- F6: show/hide the menu.
- Tab: cycle Combat, Visuals, Movement, World, and Utility pages.
- Up/Down: select an option in the current page.
- Left/Right or Enter: change a value or toggle/apply an option.
- Aim enabled: hold right mouse while the menu is closed.
  Aim eases toward the head using shortest-path rotation interpolation. Only recognized
  head sockets are targeted; a missing head socket is skipped, with no body fallback.
  Sticky lock is on by default: the head nearest your crosshair is acquired inside
  the configured angle/range, then retained while visible and alive. Releasing right
  mouse, opening the menu, or disabling aim releases the target. A lost/dead target
  is dropped and another eligible target may be acquired.
- Combat options: smoothing (4/8/12/20), acquisition angle (5/10/20/35 degrees),
  sticky lock on/off, maximum aim distance (50/100/250/500 metres), and invulnerability.
  Up/Down scrolls the Combat list to reveal the sixth item.
- Fly enabled: WASD moves, Space rises, Left Ctrl descends, Left Shift boosts.
  Flight pauses while the menu is open. Enable No collision separately to pass through walls.

## Changes

Eight additional shooter controls are available:

- Combat: prioritize the head nearest the crosshair or the nearest character;
  activate aim on right mouse (AIM), left mouse (FIRE), or either input (EITHER).
  Activation never fires a weapon automatically.
- Visuals: center crosshair, off-screen marker toggle, ESP range (0 means unlimited),
  1–4 pixel box thickness, and visible-only ESP.
- Utility: hide the persistent status HUD without hiding the F6 menu.

The defaults preserve previous aim activation and ESP behavior. The center crosshair
starts off. Additional rows are reached with Up/Down. Reset all restores these defaults.

The native menu uses a dark cyan-accented control panel, separate category tabs,
highlighted selection rows, value columns, and dedicated help/status areas. The
keyboard controls remain unchanged. Rendering still requires a gameplay check.

The latest invisibility and strict enemy-only filtering changes have been rolled back.
Smooth sticky head aim, combat options, box ESP and dead-player filtering remain.
Reloading also restores visibility if the previous revision hid your character.

ESP scans all loaded pawn subclasses, including remote characters whose controller
does not replicate locally. ESP again shows living teammates and enemies. Aim uses
the earlier simple team-ID check without excluding every unknown-team character.
It excludes spectators and
your own pawn, and has no fixed 48-character limit. Aim and ESP share live-character
filtering for zero health, reflected death/alive flags, pelvis ragdolls, and old
characters superseded by a respawn. Reflected health/stat components are checked when
available. Exact custom game death behavior still needs gameplay confirmation.
Four thin box edges surround each
on-screen character; green means visible, red means occluded. Off-screen targets
receive small outline squares at the screen edge. No player text labels are drawn.
Box sizes account for viewport DPI scaling. Characters the game has not
loaded/replicated cannot be shown.

The Movement page controls walking/crouching speed and detected numeric Blueprint
walk/run/sprint speed settings. Fly suspends standard character movement and applies
camera-relative movement directly, with vertical controls. Turning it off resumes
walking. Settings follow the next playable character after respawn. Unsupported
pawns display an error instead of stopping aim or ESP.

## Verification and limits

Native menu attachment was confirmed in the game log. The latest regression simulation
passes discovery of 60 controllerless characters, 240 outline edges, off-screen squares,
DPI scaling, hiding all boxes when ESP is disabled, menu navigation,
flight rise/restore, walking/crouching/Blueprint speed changes, opaque engine aim
rotations, and settings after respawn. The simulation does not prove engine rendering
or movement behavior in every game mode.

The observed match reports `Authority=false`: a remote server controls movement.
Client-side walk/fly changes can be corrected by that server. These movement features
need an offline/local game for reliable testing and use. Fly now reports unavailable
when the character lacks authority, instead of turning on ineffectively. This mod does not change the
remote server. The latest revision was installed without restarting your active match.
Restart the game to load it, or use UE4SS Ctrl+R hot reload while the game has focus.

Reset all restores captured movement defaults, normal world time and a 90-degree FOV.
Saved positions are restricted to the current level. Invulnerability uses Unreal's
damage flag and may not affect custom damage. Target team/death filtering depends on
properties exposed by the game.

## Install and disable

Installed mod: `HW2/Binaries/Win64/ue4ss/Mods/HW2CheatMenu/Scripts/main.lua`.
Loader: official UE4SS experimental v3.0.1-1181-g83330635.
Original executable files have not been patched.

To disable the loader, close HW2 and rename the added
`HW2/Binaries/Win64/dwmapi.dll` to `dwmapi.dll.disabled`.

Official loader: https://github.com/UE4SS-RE/RE-UE4SS/releases/tag/experimental-latest
