-- Poll native viewport pointer coordinates; keep UI clicks out of pawn input.
local M={}
local session
local function restore(c)
    if not session then return end
    local old=session; session=nil
    if c.valid(old.pc) then
        old.pc.bShowMouseCursor=old.cursor
        old.pc:SetIgnoreLookInput(false); old.pc:SetIgnoreMoveInput(false)
        StaticFindObject('/Script/UMG.Default__WidgetBlueprintLibrary'):SetInputMode_GameOnly(old.pc,false)
    end
    if old.disabled and c.valid(old.pawn) then old.pawn:EnableInput(old.pc) end
    ModRef:SetSharedVariable('HW2MousePC',false)
    ModRef:SetSharedVariable('HW2MousePawn',false)
end
function M.Cleanup(c)
    local pc=ModRef:GetSharedVariable('HW2MousePC')
    if c.valid(pc) then
        session={pc=pc,pawn=ModRef:GetSharedVariable('HW2MousePawn'),
            cursor=ModRef:GetSharedVariable('HW2MouseCursor')==true,
            disabled=ModRef:GetSharedVariable('HW2MouseDisabled')==true}
        restore(c)
    end
end
function M.Update(c)
    if session and (not c.opened or session.pc~=c.pc or session.pawn~=c.pawn) then restore(c) end
    if not c.opened or not c.view then return end
    local function held(name) return c.pc:IsInputKeyDown({KeyName=FName(name)}) end
    if not session then
        session={pc=c.pc,pawn=c.pawn,cursor=c.pc.bShowMouseCursor==true,
            left=held('LeftMouseButton'),right=held('RightMouseButton'),disabled=false}
        ModRef:SetSharedVariable('HW2MousePC',c.pc)
        ModRef:SetSharedVariable('HW2MousePawn',c.valid(c.pawn) and c.pawn or false)
        ModRef:SetSharedVariable('HW2MouseCursor',session.cursor)
        c.pc.bShowMouseCursor=true
        c.pc:SetIgnoreLookInput(true); c.pc:SetIgnoreMoveInput(true)
        if c.valid(c.pawn) then
            local ok,enabled=pcall(function() return c.pawn:InputEnabled() end)
            if not ok or enabled then c.pawn:DisableInput(c.pc); session.disabled=true end
        end
        ModRef:SetSharedVariable('HW2MouseDisabled',session.disabled)
        StaticFindObject('/Script/UMG.Default__WidgetBlueprintLibrary'):SetInputMode_GameAndUIEx(c.pc,nil,0,false,false)
    end
    local layout=StaticFindObject('/Script/UMG.Default__WidgetLayoutLibrary')
    local position=layout:GetMousePositionOnViewport(c.pc)
    local dpi=math.max(0.1,layout:GetViewportScale(c.pc))
    local action,value=c.view:HitTest(position.X/dpi-24,position.Y/dpi-70)
    c.view.hoverRow=action=='row' and value or nil
    local left,right=held('LeftMouseButton'),held('RightMouseButton')
    local pressLeft,pressRight=left and not session.left,right and not session.right
    session.left=left; session.right=right
    if action and (pressLeft or pressRight) then c.dispatch(action,value,pressRight and -1 or 1) end
end
return M
