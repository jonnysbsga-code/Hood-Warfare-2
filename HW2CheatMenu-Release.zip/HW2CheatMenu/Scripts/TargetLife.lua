-- One live-character filter shared by targeting and ESP.
local M={}
local schemas={}
local function normalized(name) return name:lower():gsub('[^%w]','') end
local deadNames={dead=true,isdead=true,bdead=true,bisdead=true,dying=true,isdying=true,bisdying=true,
    killed=true,biskilled=true,ragdoll=true,bisragdoll=true}
local aliveNames={alive=true,isalive=true,balive=true,bisalive=true}
local healthNames={health=true,currenthealth=true,healthcurrent=true,hp=true,currenthp=true,hitpoints=true,currenthitpoints=true}
local componentNames={healthcomponent=true,healthcomp=true,vitalscomponent=true,statscomponent=true,attributes=true,attributeset=true}
local function schema(o,c)
    local class=o:GetClass()
    local key=class:GetFullName()
    if schemas[key] then return schemas[key] end
    local fields={}
    for depth=1,20 do
        if not c.valid(class) then break end
        class:ForEachProperty(function(p)
            local name=p:GetFName():ToString()
            local n=normalized(name)
            if deadNames[n] then fields[#fields+1]={name,'dead'}
            elseif aliveNames[n] then fields[#fields+1]={name,'alive'}
            elseif healthNames[n] then fields[#fields+1]={name,'health'}
            elseif componentNames[n] then fields[#fields+1]={name,'component'} end
        end)
        class=class:GetSuperStruct()
    end
    schemas[key]=fields
    if #fields>0 then
        local names={}; for _,f in ipairs(fields) do names[#names+1]=f[1] end
        c.log('Life properties '..key..': '..table.concat(names,', '))
    end
    return fields
end
local function deadFields(o,c,depth)
    depth=depth or 0
    -- Include common native fields even when Blueprint reflection has no custom fields.
    for _,name in ipairs({'bIsDead','IsDead','Dead','bDead','bIsDying'}) do
        if c.prop(o,name,'boolean')==true then return true end
    end
    for _,name in ipairs({'Health','CurrentHealth','HP','CurrentHP'}) do
        local n=c.prop(o,name,'number'); if n and n<=0 then return true end
    end
    for _,f in ipairs(schema(o,c)) do
        if f[2]=='component' then
            if depth<1 then
                local component=o[f[1]]
                if c.valid(component) and deadFields(component,c,depth+1) then return true end
            end
        elseif f[2]=='health' then
            local n=c.prop(o,f[1],'number'); if n and n<=0 then return true end
        else
            local b=c.prop(o,f[1],'boolean')
            if f[2]=='dead' and b==true or f[2]=='alive' and b==false then return true end
        end
    end
    return false
end
function M.IsAlive(actor,c)
    if deadFields(actor,c) then return false end
    -- A respawn can leave the old corpse and its PlayerState behind.
    local ps=actor.PlayerState
    if c.valid(ps) then
        local ok,current=pcall(function() return ps:GetPawn() end)
        if ok and c.valid(current) and current:GetAddress()~=actor:GetAddress() then return false end
    end
    local mesh=actor.Mesh
    if c.valid(mesh) then
        local ok,ragdoll=pcall(function() return mesh:IsSimulatingPhysics(FName('pelvis')) end)
        if ok and ragdoll then return false end
    end
    return true
end
return M
