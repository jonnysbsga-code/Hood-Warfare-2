-- Native UMG canvas layout: cyan accents, separate tabs, rows and status.
local M={}
function M.New(c)
    local view={tabs={},rows={},visibleRows={}}
    local canvas=c.construct('CanvasPanel',c.root)
    c.root:SetContent(canvas)
    local function place(w,x,y,width,height)
        local slot=canvas:AddChildToCanvas(w)
        slot:SetPosition({X=x,Y=y}); slot:SetSize({X=width,Y=height})
        w:SetVisibility(4)
        return w
    end
    local function panel(x,y,w,h,tint)
        local p=c.construct('Border',canvas)
        p:SetBrushColor(tint); p:SetPadding({Left=0,Top=0,Right=0,Bottom=0})
        return place(p,x,y,w,h)
    end
    local function label(x,y,w,h,size,tint,value)
        local t=c.textWidget(canvas)
        pcall(function() local font=t.Font; font.Size=size; t:SetFont(font) end)
        t:SetColorAndOpacity({SpecifiedColor=tint,ColorUseRule=0})
        t:SetText(FText(value or ''))
        return place(t,x,y,w,h)
    end
    local cyan=c.color(0.12,0.86,1)
    local white=c.color(0.92,0.96,1)
    local muted=c.color(0.46,0.57,0.7)
    local topAccent=panel(0,0,680,4,cyan)
    panel(0,4,680,82,c.color(0.025,0.045,0.075))
    label(24,17,500,38,26,white,'HW2  /  CONTROL PANEL')
    label(26,58,360,24,12,muted,'IN-GAME CONTROLS  /  MOUSE + KEYBOARD')
    local swatches={}
    local palettes={CYAN={0.12,0.86,1},PURPLE={0.66,0.38,1},RED={1,0.28,0.35},GREEN={0.22,0.93,0.57},GOLD={1,0.73,0.22}}
    local themeNames={'CYAN','PURPLE','RED','GREEN','GOLD'}
    for i,name in ipairs(themeNames) do
        local p=palettes[name]
        swatches[i]=panel(466+(i-1)*34,58,24,16,c.color(p[1],p[2],p[3]))
    end
    panel(630,18,28,28,c.color(0.14,0.05,0.07))
    label(638,21,22,24,14,white,'X')
    for i,p in ipairs(c.pages) do
        local x=24+(i-1)*128
        view.tabs[i]={background=panel(x,96,122,28,c.color(0.03,0.05,0.08)),
            label=label(x+8,102,112,20,11,muted,p.name)}
    end
    for i=1,5 do
        local y=138+(i-1)*42
        view.rows[i]={background=panel(24,y,632,38,c.color(0.025,0.035,0.055)),
            accent=panel(24,y,3,38,cyan),label=label(38,y+8,450,25,15,white),
            value=label(500,y+8,142,25,15,cyan)}
    end
    panel(24,355,632,1,c.color(0.08,0.14,0.21))
    view.help=label(26,368,628,38,12,muted)
    view.status=label(26,410,628,32,11,c.color(0.5,0.76,0.85))
    pcall(function() view.help:SetAutoWrapText(true); view.status:SetAutoWrapText(true) end)
    label(26,454,475,22,11,muted,'CLICK  CHANGE   /   RIGHT CLICK  PREVIOUS   /   F6  CLOSE')
    panel(526,449,62,26,c.color(0.04,0.08,0.12)); label(539,454,52,22,11,white,'PREV')
    panel(594,449,62,26,c.color(0.04,0.08,0.12)); label(607,454,52,22,11,white,'NEXT')
    function view:HitTest(x,y)
        if x>=630 and x<=658 and y>=18 and y<=46 then return 'close' end
        if y>=58 and y<=74 then
            for i,name in ipairs(themeNames) do
                local left=466+(i-1)*34
                if x>=left and x<=left+24 then return 'theme',name end
            end
        end
        if y>=96 and y<=124 then
            for i=1,#c.pages do
                local left=24+(i-1)*128
                if x>=left and x<=left+122 then return 'tab',i end
            end
        end
        if x>=24 and x<=656 and y>=138 and y<348 then
            local n=math.floor((y-138)/42)+1
            if (y-138)%42<38 and self.visibleRows[n] then return 'row',self.visibleRows[n] end
        end
        if y>=449 and y<=475 then
            if x>=526 and x<=588 then return 'scroll',-1 end
            if x>=594 and x<=656 then return 'scroll',1 end
        end
    end
    function view:Update(page,selected,labels,keys,state,help,status)
        local theme=palettes[state.theme or 'CYAN'] or {(state.accentR or 31)/255,(state.accentG or 219)/255,(state.accentB or 255)/255}
        cyan=c.color(theme[1],theme[2],theme[3])
        topAccent:SetBrushColor(cyan)
        for i,t in ipairs(self.tabs) do
            t.background:SetBrushColor(i==page and c.color(theme[1]*0.22,theme[2]*0.22,theme[3]*0.22) or c.color(0.03,0.05,0.08))
            t.label:SetColorAndOpacity({SpecifiedColor=i==page and cyan or muted,ColorUseRule=0})
        end
        local offset=0
        for n,index in ipairs(c.pages[page].rows) do
            if index==selected then offset=math.max(0,n-#self.rows); break end
        end
        for n,r in ipairs(self.rows) do
            local index=c.pages[page].rows[n+offset]
            self.visibleRows[n]=index
            local visibility=index and 4 or 1
            for _,w in pairs(r) do w:SetVisibility(visibility) end
            if index then
                local chosen=index==selected
                local highlighted=chosen or self.hoverRow==index
                r.background:SetBrushColor(highlighted and c.color(theme[1]*0.13+0.015,theme[2]*0.13+0.015,theme[3]*0.13+0.015) or c.color(0.025,0.035,0.055))
                r.accent:SetBrushColor(cyan)
                r.accent:SetVisibility(chosen and 4 or 1)
                r.label:SetText(FText(labels[index]))
                local value=keys[index] and state[keys[index]]
                if type(value)=='boolean' then value=value and 'ON' or 'OFF' end
                r.value:SetText(FText(value~=nil and tostring(value) or 'APPLY'))
                r.value:SetColorAndOpacity({SpecifiedColor=value=='OFF' and muted or cyan,ColorUseRule=0})
            end
        end
        self.help:SetText(FText(help))
        self.status:SetText(FText(status))
    end
    return view
end
return M
