-- Native UMG menu. All reflection and widgets stay on the game thread.
local opened,selected,status=false,1,'F6 menu | RMB aim | Space/Ctrl fly up/down'
local s={aim=false,esp=false,fly=false,speed=1,god=false,ghost=false,jump=1,gravity=1,fov=90,time=1,freeze=false,smoothing=8,cone=20,sticky=true,range=250}
local function extraDefaults()
    s.crosshair=false; s.offscreen=true; s.espRange=0; s.boxWidth=2
    s.visibleESP=false; s.priority='CROSSHAIR'; s.trigger='AIM'; s.quietHUD=false
    s.theme='CYAN'; s.accentR=31; s.accentG=219; s.accentB=255
end
extraDefaults()
local labels={'Aimbot (hold right mouse)','Player / AI ESP','Fly','Walk speed','Invulnerability','No collision','Jump multiplier','Gravity multiplier','Field of view','World time scale','Freeze AI','Save position','Return to position','Reset all'}
local keys={'aim','esp','fly','speed','god','ghost','jump','gravity','fov','time','freeze'}
labels[15]='Aim smoothing'; keys[15]='smoothing'
labels[16]='Acquisition angle'; keys[16]='cone'
labels[17]='Sticky target lock'; keys[17]='sticky'
labels[18]='Maximum aim distance (m)'; keys[18]='range'
labels[19]='Center crosshair'; keys[19]='crosshair'
labels[20]='Off-screen ESP markers'; keys[20]='offscreen'
labels[21]='ESP range (0 = unlimited)'; keys[21]='espRange'
labels[22]='ESP line thickness'; keys[22]='boxWidth'
labels[23]='ESP visible characters only'; keys[23]='visibleESP'
labels[24]='Aim target priority'; keys[24]='priority'
labels[25]='Aim activation'; keys[25]='trigger'
labels[26]='Hide status HUD'; keys[26]='quietHUD'
labels[27]='Menu color theme'; keys[27]='theme'
labels[28]='Custom accent: red'; keys[28]='accentR'
labels[29]='Custom accent: green'; keys[29]='accentG'
labels[30]='Custom accent: blue'; keys[30]='accentB'
local pages={
    {name='COMBAT',rows={1,15,16,17,18,5,24,25}},
    {name='VISUALS',rows={2,9,19,20,21,22,23}},
    {name='MOVEMENT',rows={3,4,6,7,8}},
    {name='WORLD',rows={10,11}},
    {name='SETTINGS',rows={12,13,14,26,27,28,29,30}},
}
local page,row=3,1
selected=pages[page].rows[row]
local help={
    'Hold right mouse: smooth head-only aim. Characters without a verified head bone are skipped.',
    'Boxes around loaded characters; small edge squares for off-screen targets.',
    'WASD move | Space rise | Ctrl descend | Shift boost.',
    'Changes walking, crouching and detected walk/sprint speed settings.',
    'Uses the engine damage flag. Custom game damage may ignore it.',
    'Toggle collision for your character.',
    'Increase jump height.', 'Reduce gravity while walking.',
    'Choose the camera field of view.', 'Change world simulation speed.',
    'Freeze locally controlled AI.', 'Save your current position in this level.',
    'Return to the saved position in this level.', 'Restore captured defaults and turn all cheats off.',
}
local pc,pawn,gs,viewport,menu,text,hint,movement,baseline,pawnId,saved
help[15]='Lower values ease in slowly. Higher values follow the head more quickly.'
help[16]='Automatically acquire the nearest head to your crosshair inside this angle.'
help[17]='Hold the same living, visible target while aiming. Release right mouse to unlock.'
help[18]='Only acquire targets within this distance.'
help[19]='Draw a small cyan crosshair at the center of the viewport.'
help[20]='Show or hide small squares for targets outside the screen.'
help[21]='Limit ESP distance in metres. Zero means no distance limit.'
help[22]='Choose one to four pixel box outlines, adjusted for display scaling.'
help[23]='Hide ESP boxes for characters blocked by scenery.'
help[24]='Acquire the head closest to the crosshair, or the nearest eligible character.'
help[25]='Activate while aiming, firing, or holding either input. Does not fire for you.'
help[26]='Hide the persistent top-left status strip while keeping F6 available.'
help[27]='Pick a preset here or click a color swatch in the header.'
help[28]='Change red in 16-step increments. Custom RGB overrides the preset.'
help[29]='Change green in 16-step increments. Custom RGB overrides the preset.'
help[30]='Change blue in 16-step increments. Custom RGB overrides the preset.'
local lockedTarget,lockOwner
local menuView
local menuRenderer=require('MenuView')
local mouseMenu=require('MouseMenu')
local targets,frozen,seenClasses,errors={},{},{},{}
local gameSpeeds,ownedWidgets={},{}
local damageDefault,collisionDefault=true,true
local wasFlying=false
local loadedCount,espCount=0,0
local trackedPawns,trackedWorld={},nil
local frame=0
local function log(t) print('[HW2Menu] '..t..'\n') end
local function valid(o)
    local ok,result=pcall(function() return o:IsValid() end)
    return ok and result==true
end
local function guard(section,fn)
    local ok,err=pcall(fn)
    if not ok then
        err=tostring(err); status=section..': '..err:sub(1,130)
        if errors[section]~=err then log(section..': '..err); errors[section]=err end
    end
    return ok
end
local function prop(o,name,kind)
    local ok,v=pcall(function() return o[name] end)
    if ok and type(v)==kind then return v end
end
local function vec(v) return {X=v.X,Y=v.Y,Z=v.Z} end
local function color(r,g,b,a) return {R=r,G=g,B=b,A=a or 1} end
local function slot(x,y,w,h,z)
    return {Anchors={Minimum={X=0,Y=0},Maximum={X=0,Y=0}},Offsets={Left=x,Top=y,Right=w,Bottom=h},
        Alignment={X=0,Y=0},ZOrder=z or 2000,bAutoRemoveOnWorldRemoved=true}
end
local function construct(class,outer)
    local c=StaticFindObject('/Script/UMG.'..class)
    assert(valid(c),'Missing UMG class '..class)
    local o=StaticConstructObject(c,outer,FName('None'),0x40,0,false,false)
    assert(valid(o),'Could not construct '..class)
    ownedWidgets[#ownedWidgets+1]=o
    ModRef:SetSharedVariable('HW2NativeWidget'..#ownedWidgets,o)
    ModRef:SetSharedVariable('HW2NativeWidgetCount',#ownedWidgets)
    return o
end
local function textWidget(outer)
    local t=construct('TextBlock',outer)
    pcall(function() local font=t.Font; font.Size=16; t:SetFont(font) end)
    t:SetColorAndOpacity({SpecifiedColor=color(0.8,1,0.9),ColorUseRule=0})
    t:SetShadowColorAndOpacity(color(0,0,0)); t:SetShadowOffset({X=1,Y=1})
    t:SetVisibility(4)
    return t
end
local function ensureUI()
    if not valid(viewport) then viewport=FindFirstOf('GameViewportSubsystem') end
    assert(valid(viewport),'GameViewportSubsystem not ready')
    if not valid(menu) then
        menu=construct('Border',pc)
        menu:SetBrushColor(color(0.012,0.02,0.035,0.97))
        menu:SetPadding({Left=0,Top=0,Right=0,Bottom=0})
        menuView=menuRenderer.New({root=menu,construct=construct,textWidget=textWidget,color=color,pages=pages})
        log('Native menu widgets created')
    end
    if not viewport:IsWidgetAdded(menu) then
        assert(viewport:AddWidget(menu,slot(24,70,680,480,10000)),'Viewport rejected menu')
        log('Native menu added to game viewport')
    end
    menu:SetVisibility(opened and 4 or 1)
    if not valid(hint) then hint=textWidget(pc) end
    if not viewport:IsWidgetAdded(hint) then viewport:AddWidget(hint,slot(24,18,800,42,10001)) end
    hint:SetText(FText('HW2 | F6 menu | Aim '..(s.aim and 'ON' or 'OFF')..' | ESP '..(s.esp and ('ON '..espCount..'/'..loadedCount) or 'OFF')..' | Fly '..(s.fly and 'ON' or 'OFF')..' | Speed '..s.speed..'x'))
    hint:SetVisibility(s.quietHUD and 1 or 4)
    if opened then
        local note=status
        if page==3 and valid(pawn) then
            local ok,authority=pcall(function() return pawn:HasAuthority() end)
            if ok and not authority then note=note..' | Movement is server controlled.' end
        end
        menuView:Update(page,selected,labels,keys,s,help[selected],note)
    end
end
local function findPlayer()
    gs=StaticFindObject('/Script/Engine.Default__GameplayStatics')
    for _,c in ipairs(FindAllOf('PlayerController') or {}) do
        if valid(c) and c:IsLocalController() then
            pc=c; local p=c:K2_GetPawn(); pawn=valid(p) and p or nil; return
        end
    end
    pc=nil; pawn=nil
end
local function captureMovement()
    if not valid(pawn) then return end
    local id=pawn:GetFullName()
    if id==pawnId then return end
    pawnId=id; movement=nil; baseline=nil; gameSpeeds={}; wasFlying=false
    damageDefault=prop(pawn,'bCanBeDamaged','boolean')
    collisionDefault=pawn:GetActorEnableCollision()
    local m=pawn.CharacterMovement
    if not valid(m) then m=pawn:GetComponentByClass(StaticFindObject('/Script/Engine.CharacterMovementComponent')) end
    if valid(m) and prop(m,'MaxWalkSpeed','number') then
        movement=m
        baseline={speed=m.MaxWalkSpeed,fly=m.MaxFlySpeed,jump=m.JumpZVelocity,gravity=m.GravityScale,
            crouch=m.MaxWalkSpeedCrouched,acceleration=m.MaxAcceleration,mode=m.MovementMode}
        local class=pawn:GetClass()
        for depth=1,16 do
            if not valid(class) then break end
            class:ForEachProperty(function(property)
                local name=property:GetFName():ToString()
                local lower=name:lower()
                if lower:find('speed') and (lower:find('walk') or lower:find('sprint') or lower:find('run')) and not lower:find('anim') then
                    local v=prop(pawn,name,'number')
                    if v and v>10 and v<10000 then gameSpeeds[name]=v; log('Movement setting '..name..'='..v) end
                end
            end)
            class=class:GetSuperStruct()
        end
    end
    log('Local pawn '..id..'; CharacterMovement supported: '..tostring(valid(movement)))
    guard('Movement diagnostics',function()
        log('Authority='..tostring(pawn:HasAuthority())..'; walk='..tostring(valid(movement) and movement.MaxWalkSpeed))
    end)
end
local function restoreFrozen()
    for _,f in pairs(frozen) do if valid(f.actor) then f.actor.CustomTimeDilation=f.scale end end
    frozen={}
end
local function reset()
    restoreFrozen()
    if valid(movement) and baseline then
        movement.MaxWalkSpeed=baseline.speed; movement.MaxFlySpeed=baseline.fly
        movement.JumpZVelocity=baseline.jump; movement.GravityScale=baseline.gravity
        movement.MaxWalkSpeedCrouched=baseline.crouch; movement.MaxAcceleration=baseline.acceleration
        movement:SetMovementMode(baseline.mode,0)
        for name,v in pairs(gameSpeeds) do pawn[name]=v end
    end
    if valid(pawn) then
        if s.god and damageDefault~=nil then pawn.bCanBeDamaged=damageDefault end
        if s.ghost then pawn:SetActorEnableCollision(collisionDefault) end
        gs:SetGlobalTimeDilation(pawn,1)
    end
    if valid(pc) then pc:FOV(90) end
    s={aim=false,esp=false,fly=false,speed=1,god=false,ghost=false,jump=1,gravity=1,fov=90,time=1,freeze=false,smoothing=8,cone=20,sticky=true,range=250}
    extraDefaults()
    lockedTarget=nil; lockOwner=nil
    wasFlying=false; status='Cheats reset'
end
local function cycle(k,list,d)
    local n=1
    for i,v in ipairs(list) do if v==s[k] then n=i end end
    s[k]=list[((n-1+d)%#list)+1]
end
local function change(d)
    if selected==1 then s.aim=not s.aim
    elseif selected==2 then s.esp=not s.esp
    elseif selected==15 then cycle('smoothing',{4,8,12,20},d)
    elseif selected==16 then cycle('cone',{5,10,20,35},d)
    elseif selected==17 then s.sticky=not s.sticky; lockedTarget=nil
    elseif selected==18 then cycle('range',{50,100,250,500},d)
    elseif selected==19 then s.crosshair=not s.crosshair
    elseif selected==20 then s.offscreen=not s.offscreen
    elseif selected==21 then cycle('espRange',{0,100,250,500,1000},d)
    elseif selected==22 then cycle('boxWidth',{1,2,3,4},d)
    elseif selected==23 then s.visibleESP=not s.visibleESP
    elseif selected==24 then cycle('priority',{'CROSSHAIR','DISTANCE'},d); lockedTarget=nil
    elseif selected==25 then cycle('trigger',{'AIM','FIRE','EITHER'},d); lockedTarget=nil
    elseif selected==26 then s.quietHUD=not s.quietHUD
    elseif selected==27 then cycle('theme',{'CYAN','PURPLE','RED','GREEN','GOLD','CUSTOM'},d)
    elseif selected>=28 and selected<=30 then
        local key=keys[selected]; s[key]=math.max(0,math.min(255,s[key]+d*16)); s.theme='CUSTOM'
    else
        assert(valid(pawn),'Enter a playable single-player level first')
        if selected==3 or selected==4 or selected==7 or selected==8 then
            assert(valid(movement) and baseline,'This pawn has no supported CharacterMovement component')
        end
        if selected==3 then
            if not s.fly then
                assert(pawn:HasAuthority(),'Fly unavailable: this match is server controlled. Use a local/offline game.')
            end
            s.fly=not s.fly
        elseif selected==4 then cycle('speed',{1,1.5,2,3,5},d)
        elseif selected==5 then s.god=not s.god; pawn.bCanBeDamaged=not s.god
        elseif selected==6 then s.ghost=not s.ghost; pawn:SetActorEnableCollision(not s.ghost)
        elseif selected==7 then cycle('jump',{1,2,3,5},d)
        elseif selected==8 then cycle('gravity',{1,0.5,0.25,0.1},d)
        elseif selected==9 then cycle('fov',{90,100,110,120,70},d); pc:FOV(s.fov)
        elseif selected==10 then cycle('time',{1,0.5,0.25,1.5,2},d); gs:SetGlobalTimeDilation(pawn,s.time)
        elseif selected==11 then s.freeze=not s.freeze; if not s.freeze then restoreFrozen() end
        elseif selected==12 then saved={location=vec(pawn:K2_GetActorLocation()),world=pawn:GetWorld():GetAddress()}
        elseif selected==13 then
            assert(saved and saved.world==pawn:GetWorld():GetAddress(),'Save a position in this level first')
            pawn:K2_SetActorLocation(saved.location,false,{},true)
        elseif selected==14 then reset(); return end
    end
    status=labels[selected]..' updated'
end
local function mouseDispatch(action,value,direction)
    if action=='close' then opened=false
    elseif action=='tab' then page=value; row=1; selected=pages[page].rows[row]
    elseif action=='theme' then s.theme=value; status=value..' theme selected'
    elseif action=='scroll' then
        row=math.max(1,math.min(#pages[page].rows,row+value*5)); selected=pages[page].rows[row]
    elseif action=='row' then
        selected=value
        for i,index in ipairs(pages[page].rows) do if index==value then row=i; break end end
        change(direction)
    end
end
local targetLife=require('TargetLife')
local function isTarget(a)
    if not valid(a) or a:GetAddress()==pawn:GetAddress() then return false end
    -- Remote players do not replicate their controller to this machine.
    if a:IsA('/Script/Engine.SpectatorPawn') or a:GetClass():GetFName():ToString():lower():find('spectator') then return false end
    if not a:IsA('/Script/Engine.Character') and not valid(a.PlayerState) then return false end
    if not targetLife.IsAlive(a,{valid=valid,prop=prop,log=log}) then return false end
    return true
end
local function enemy(a)
    if not isTarget(a) then return false end
    for _,name in ipairs({'TeamId','TeamID','TeamNumber'}) do
        local mine,theirs=prop(pawn,name,'number'),prop(a,name,'number')
        if mine and theirs and mine==theirs then return false end
    end
    return true
end
local function verifiedHeadPosition(a)
    local mesh=a.Mesh
    if valid(mesh) then
        for _,bone in ipairs({'head','Head','b_head','Bip01 Head','Bip001 Head','mixamorig:Head'}) do
            if mesh:DoesSocketExist(FName(bone)) then return vec(mesh:GetSocketLocation(FName(bone))) end
        end
    end
    return nil
end
local function headPosition(a)
    local head=verifiedHeadPosition(a)
    if head then return head end
    local p=vec(a:K2_GetActorLocation()); p.Z=p.Z+65; return p
end
local function scanTargets()
    targets={}
    local world=pawn:GetWorld():GetAddress()
    if trackedWorld~=world then
        trackedWorld=world; trackedPawns={}
        local pawnClass=StaticFindObject('/Script/Engine.Pawn')
        ForEachUObject(function(o)
            if valid(o) and o:IsA(pawnClass) and not o:HasAnyFlags(0x30) then
                trackedPawns[#trackedPawns+1]=o
            end
        end)
    end
    local live,seen={},{}
    for _,a in ipairs(trackedPawns) do
        if valid(a) and a:GetWorld():GetAddress()==world and not seen[a:GetAddress()] then
            seen[a:GetAddress()]=true; live[#live+1]=a
        if isTarget(a) then
            targets[#targets+1]=a
            local class=a:GetClass():GetFullName()
            if not seenClasses[class] then seenClasses[class]=true; log('Target class '..class) end
        end
        end
    end
    trackedPawns=live
    loadedCount=#targets
end
local function aim()
    local aiming=pc:IsInputKeyDown({KeyName=FName('RightMouseButton')})
    local firing=pc:IsInputKeyDown({KeyName=FName('LeftMouseButton')})
    local active=s.trigger=='AIM' and aiming or s.trigger=='FIRE' and firing or s.trigger=='EITHER' and (aiming or firing)
    if not s.aim or opened or not active then
        lockedTarget=nil; lockOwner=nil; return
    end
    local cam=pc.PlayerCameraManager; assert(valid(cam),'No camera manager')
    local eye=vec(cam:GetCameraLocation())
    local mathlib=StaticFindObject('/Script/Engine.Default__KismetMathLibrary')
    local forward=vec(mathlib:GetForwardVector(cam:GetCameraRotation()))
    local best,bestActor,bestScore=nil,nil,-math.huge
    local function candidate(a,threshold)
            if enemy(a) and pc:LineOfSightTo(a,eye,false) then
                local pos=verifiedHeadPosition(a)
                if not pos then return end
                local dx,dy,dz=pos.X-eye.X,pos.Y-eye.Y,pos.Z-eye.Z
                local length=math.sqrt(dx*dx+dy*dy+dz*dz)
                if length>s.range*100 then return end
                local score=length>0 and (dx*forward.X+dy*forward.Y+dz*forward.Z)/length or -1
                if score>threshold then return mathlib:FindLookAtRotation(eye,pos),score,length end
            end
    end
    if s.sticky and valid(lockedTarget) and lockOwner==pawn:GetAddress() then
        guard('Locked target',function()
            best=candidate(lockedTarget,math.cos(math.rad(math.min(80,s.cone+15))))
            if best then bestActor=lockedTarget end
        end)
    end
    if not best then
        for _,a in ipairs(targets) do
            guard('Target',function()
                local rotation,score,distance=candidate(a,math.cos(math.rad(s.cone)))
                local priority=rotation and (s.priority=='DISTANCE' and -distance or score)
                if rotation and priority>bestScore then best=rotation; bestActor=a; bestScore=priority end
            end)
        end
    end
    lockedTarget=bestActor; lockOwner=pawn:GetAddress()
    if best then
        local dt=math.min(0.1,math.max(0,gs:GetWorldDeltaSeconds(pawn)))
        local alpha=1-math.exp(-s.smoothing*dt)
        -- Pass opaque engine rotators through RLerp; shortest-path yaw avoids wraparound jumps.
        pc:SetControlRotation(mathlib:RLerp(pc:GetControlRotation(),best,alpha,true))
    end
end
local boxESP=require('BoxESP')
local crosshairParts={}
local function updateCrosshair()
    if not valid(viewport) then return end
    if not s.crosshair then
        for _,w in ipairs(crosshairParts) do if valid(w) then w:SetVisibility(1) end end
        return
    end
    local layout=StaticFindObject('/Script/UMG.Default__WidgetLayoutLibrary')
    local size=layout:GetViewportSize(pc); local dpi=math.max(0.1,layout:GetViewportScale(pc))
    local x,y=size.X/2,size.Y/2
    for i,r in ipairs({{x-12,y-1,8,2},{x+4,y-1,8,2},{x-1,y-12,2,8},{x-1,y+4,2,8}}) do
        local w=crosshairParts[i]
        if not valid(w) then w=construct('Border',pc); crosshairParts[i]=w end
        local position=slot(0,0,r[3]/dpi,r[4]/dpi,3000)
        if not viewport:IsWidgetAdded(w) then viewport:AddWidget(w,position) end
        position=viewport:SetWidgetSlotPosition(position,w,{X=r[1],Y=r[2]},true)
        viewport:SetWidgetSlot(w,position)
        w:SetBrushColor(color(0.12,0.86,1)); w:SetVisibility(4)
    end
end
local function updateESP()
    if not valid(viewport) then return end
    espCount=boxESP.Update({enabled=s.esp and valid(pawn),pc=pc,viewport=viewport,targets=targets,
        valid=valid,vec=vec,color=color,slot=slot,guard=guard,isTarget=isTarget,
        headPosition=headPosition,construct=construct,offscreen=s.offscreen,range=s.espRange,
        thickness=s.boxWidth,visibleOnly=s.visibleESP})
end
local function movementTick()
    if not valid(movement) or not baseline then return end
    movement.MaxWalkSpeed=baseline.speed*s.speed; movement.MaxFlySpeed=baseline.fly*s.speed
    movement.MaxWalkSpeedCrouched=baseline.crouch*s.speed
    movement.MaxAcceleration=baseline.acceleration*math.max(1,s.speed)
    for name,v in pairs(gameSpeeds) do pawn[name]=v*s.speed end
    movement.JumpZVelocity=baseline.jump*s.jump; movement.GravityScale=baseline.gravity*s.gravity
    if s.fly then
        -- Game blueprints can reset MOVE_Flying; manual flight keeps controls independent.
        movement:StopMovementImmediately(); movement:SetMovementMode(0,0)
        movement.GravityScale=0; wasFlying=true
        if opened then return end
        local function held(key) return pc:IsInputKeyDown({KeyName=FName(key)}) and 1 or 0 end
        local mathlib=StaticFindObject('/Script/Engine.Default__KismetMathLibrary')
        local rotation=pc.PlayerCameraManager:GetCameraRotation()
        local forward=vec(mathlib:GetForwardVector(rotation)); local right=vec(mathlib:GetRightVector(rotation))
        local f,r,z=held('W')-held('S'),held('D')-held('A'),held('SpaceBar')-held('LeftControl')
        local x,y=forward.X*f+right.X*r,forward.Y*f+right.Y*r
        local length=math.sqrt(x*x+y*y+z*z)
        if length>0 then
            local dt=math.min(0.05,math.max(0.001,gs:GetWorldDeltaSeconds(pawn)))
            local speed=math.max(600,baseline.speed)*s.speed*(held('LeftShift')==1 and 2 or 1)
            pawn:K2_AddActorWorldOffset({X=x/length*speed*dt,Y=y/length*speed*dt,Z=z/length*speed*dt},not s.ghost,{},false)
        end
    elseif wasFlying then
        movement:SetMovementMode(1,0); wasFlying=false
    end
end
RegisterKeyBind(Key.F6,function() opened=not opened end)
RegisterKeyBind(Key.TAB,function() if opened then page=page%#pages+1; row=1; selected=pages[page].rows[row] end end)
RegisterKeyBind(Key.UP_ARROW,function() if opened then row=((row-2)%#pages[page].rows)+1; selected=pages[page].rows[row] end end)
RegisterKeyBind(Key.DOWN_ARROW,function() if opened then row=row%#pages[page].rows+1; selected=pages[page].rows[row] end end)
RegisterKeyBind(Key.LEFT_ARROW,function() if opened then guard('Menu',function() change(-1) end) end end)
RegisterKeyBind(Key.RIGHT_ARROW,function() if opened then guard('Menu',function() change(1) end) end end)
RegisterKeyBind(Key.RETURN,function() if opened then guard('Menu',function() change(1) end) end end)
NotifyOnNewObject('/Script/Engine.Pawn',function(o) trackedPawns[#trackedPawns+1]=o end)
local function tick()
    frame=frame+1
    if frame%15==1 or not valid(pc) then guard('Player',findPlayer) end
    if not valid(pc) then return end
    guard('Native UI',ensureUI)
    guard('Mouse menu',function()
        mouseMenu.Update({opened=opened,pc=pc,pawn=pawn,view=menuView,valid=valid,dispatch=mouseDispatch})
    end)
    guard('Crosshair',updateCrosshair)
    if not valid(pawn) then return end
    guard('Movement discovery',captureMovement)
    if frame%15==1 then guard('Scan',scanTargets) end
    guard('Aim',aim)
    guard('Movement',movementTick)
    if frame%2==0 then guard('ESP',updateESP) end
    if s.freeze then guard('Freeze',function()
        for _,a in ipairs(targets) do
            if valid(a) then
                local c=a.Controller
                if valid(c) and not c:IsPlayerController() then
                    local id=a:GetAddress()
                    if not frozen[id] then frozen[id]={actor=a,scale=a.CustomTimeDilation} end
                    a.CustomTimeDilation=0
                end
            end
        end
    end) end
end
-- Remove native widgets retained by the previous hot-reload instance.
ExecuteInGameThread(function()
    guard('Mouse cleanup',function() mouseMenu.Cleanup({valid=valid}) end)
    local oldHidden=ModRef:GetSharedVariable('HW2HiddenPawn')
    if valid(oldHidden) then
        guard('Visibility cleanup',function() oldHidden:SetActorHiddenInGame(ModRef:GetSharedVariable('HW2HiddenDefault')==true) end)
    end
    ModRef:SetSharedVariable('HW2HiddenPawn',false)
    local count=ModRef:GetSharedVariable('HW2NativeWidgetCount')
    local v=FindFirstOf('GameViewportSubsystem')
    if type(count)=='number' and valid(v) then
        for i=1,count do
            local w=ModRef:GetSharedVariable('HW2NativeWidget'..i)
            if valid(w) then guard('UI cleanup',function() v:RemoveWidget(w) end) end
        end
    end
    ModRef:SetSharedVariable('HW2NativeWidgetCount',0)
end)
assert(type(LoopInGameThreadWithDelay)=='function','UE4SS delayed game-thread API required')
LoopInGameThreadWithDelay(16,tick)
log('v10 loaded: clickable native menu, preset themes and custom RGB accent colors.')
