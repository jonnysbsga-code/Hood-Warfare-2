-- Four native UMG strips per character: transparent center, no text labels.
local M={}
local boxes={}
function M.Update(c)
    local used=0
    if c.enabled then
        local layout=StaticFindObject('/Script/UMG.Default__WidgetLayoutLibrary')
        local size=layout:GetViewportSize(c.pc)
        local dpi=math.max(0.1,layout:GetViewportScale(c.pc))
        local camera=c.pc.PlayerCameraManager
        local eye=c.vec(camera:GetCameraLocation())
        local mathlib=StaticFindObject('/Script/Engine.Default__KismetMathLibrary')
        local rotation=camera:GetCameraRotation()
        local forward=c.vec(mathlib:GetForwardVector(rotation))
        local right=c.vec(mathlib:GetRightVector(rotation))
        local up=c.vec(mathlib:GetUpVector(rotation))
        for _,actor in ipairs(c.targets) do
            c.guard('Box ESP',function()
                if not c.isTarget(actor) then return end
                local head=c.headPosition(actor)
                local dx,dy,dz=head.X-eye.X,head.Y-eye.Y,head.Z-eye.Z
                if (c.range or 0)>0 and dx*dx+dy*dy+dz*dz>(c.range*100)^2 then return end
                local visible=c.pc:LineOfSightTo(actor,eye,false)
                if c.visibleOnly and not visible then return end
                local point={X=0,Y=0}
                local projected=c.pc:ProjectWorldLocationToScreen(head,point,false)
                local offscreen=not projected or point.X<8 or point.Y<8 or point.X>size.X-8 or point.Y>size.Y-8
                local x,y,w,h
                if offscreen then
                    if c.offscreen==false then return end
                    local dx,dy,dz=head.X-eye.X,head.Y-eye.Y,head.Z-eye.Z
                    local horizontal=dx*right.X+dy*right.Y+dz*right.Z
                    local vertical=-(dx*up.X+dy*up.Y+dz*up.Z)
                    local front=dx*forward.X+dy*forward.Y+dz*forward.Z
                    if math.abs(horizontal)+math.abs(vertical)<0.001 then horizontal=front<0 and -1 or 1 end
                    local ex,ey=math.max(1,size.X/2-20),math.max(1,size.Y/2-20)
                    local factor=1/math.max(math.abs(horizontal)/ex,math.abs(vertical)/ey,0.0001)
                    x,y,w,h=size.X/2+horizontal*factor-6,size.Y/2+vertical*factor-6,12,12
                else
                    local center=c.vec(actor:K2_GetActorLocation())
                    local halfHeight=90
                    if c.valid(actor.CapsuleComponent) then halfHeight=actor.CapsuleComponent:GetScaledCapsuleHalfHeight() end
                    local top,bottom={X=0,Y=0},{X=0,Y=0}
                    if not c.pc:ProjectWorldLocationToScreen({X=center.X,Y=center.Y,Z=center.Z+halfHeight+8},top,false) then return end
                    if not c.pc:ProjectWorldLocationToScreen({X=center.X,Y=center.Y,Z=center.Z-halfHeight},bottom,false) then return end
                    h=math.max(8,math.abs(bottom.Y-top.Y)); w=math.max(6,h*0.48)
                    x=(top.X+bottom.X)/2-w/2; y=math.min(top.Y,bottom.Y)
                    local rightEdge,bottomEdge=math.min(size.X-2,x+w),math.min(size.Y-2,y+h)
                    x=math.max(2,x); y=math.max(2,y); w=rightEdge-x; h=bottomEdge-y
                    if w<=0 or h<=0 then return end
                end
                used=used+1
                local box=boxes[used]
                if not box then box={}; boxes[used]=box end
                local tint=visible and c.color(0.2,1,0.3) or c.color(1,0.3,0.2)
                local thickness=math.min(c.thickness or 2,w/2,h/2)
                local rects={{x,y,w,thickness},{x,y+h-thickness,w,thickness},
                    {x,y,thickness,h},{x+w-thickness,y,thickness,h}}
                for i,r in ipairs(rects) do
                    local edge=box[i]
                    if not c.valid(edge) then
                        edge=c.construct('Border',c.pc); box[i]=edge
                        edge:SetPadding({Left=0,Top=0,Right=0,Bottom=0})
                    end
                    local slot=c.slot(0,0,r[3]/dpi,r[4]/dpi,2000)
                    if not c.viewport:IsWidgetAdded(edge) then assert(c.viewport:AddWidget(edge,slot),'Could not attach ESP box') end
                    slot=c.viewport:SetWidgetSlotPosition(slot,edge,{X=r[1],Y=r[2]},true)
                    c.viewport:SetWidgetSlot(edge,slot)
                    edge:SetBrushColor(tint); edge:SetVisibility(4)
                end
            end)
        end
    end
    for i=used+1,#boxes do
        for _,edge in ipairs(boxes[i]) do if c.valid(edge) then edge:SetVisibility(1) end end
    end
    return used
end
return M
